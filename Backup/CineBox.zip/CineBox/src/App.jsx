import React from 'react'
import NavBar from './components/NavBar'
import MovieContent from './components/MovieContent'
import Footer from './components/Footer'
import { MoviesProvider } from './context/MoviesContext'

function App() {
  return (
    <MoviesProvider>
      <div className='min-h-screen text-white'>
        <NavBar />
        <main>
          <MovieContent />
        </main>
        <Footer />
      </div>
    </MoviesProvider>
  )
}

export default App
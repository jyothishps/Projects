import React, { useEffect, useRef, useState } from "react";
import { useMovies } from "../context/MoviesContext";
import { getImageURL, searchMovies } from "../services/api";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

function NavBar() {
  const { openMovieDetails } = useMovies();
  const { user, logout } = useAuth();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const [searchQry, setSearchQry] = useState("");
  const [searchResult, setSearchResult] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showSearchResult, setShowSearchResult] = useState(false);
  const searchContainerRef = useRef(null);
  const mobileMenuRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const handleSearch = async () => {
      if (searchQry.trim().length > 2) {
        setIsSearching(true);
        try {
          const result = await searchMovies(searchQry);
          setSearchResult(result ? result.slice(0, 5) : []);
        } catch (error) {
          console.error("Error searching movies:", error);
        } finally {
          setIsSearching(false);
          setShowSearchResult(true);
        }
      } else {
        setSearchResult([]);
        setShowSearchResult(false);
      }
    };
    const debounceTimer = setTimeout(() => {
      handleSearch();
    }, 500);

    return () => {
      clearTimeout(debounceTimer);
    };
  }, [searchQry]);

  const handleSearchFocus = () => {
    if (searchQry.trim().length > 2 && searchResult.length > 0) {
      setShowSearchResult(true);
    }
  };

  useEffect(() => {
    const handleClickOutSide = (e) => {
      const isOutsideDesktop =
        searchContainerRef.current &&
        !searchContainerRef.current.contains(e.target);
      const isOutsideMobile =
        mobileMenuRef.current && !mobileMenuRef.current.contains(e.target);

      if (isOutsideDesktop && isOutsideMobile) {
        setShowSearchResult(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutSide);
    return () => {
      document.removeEventListener("mousedown", handleClickOutSide);
    };
  }, []);

  const handleMovieSelect = (movieId) => {
    openMovieDetails(movieId);
    setShowSearchResult(false);
    setSearchQry("");
    setIsMobileMenuOpen(false);
  };

  return (
    <header
      className={`fixed w-full z-50 transition-all duration-300 ${isScrolled || isMobileMenuOpen
        ? "bg-neutral-900/95 backdrop-blur-md shadow-lg"
        : "bg-transparent"
        }`}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/home" className="flex items-center">
            <span className="text-purple-500 font-bold text-3xl">
              Cine<span className="text-white">Box</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <a
              href="#"
              className="text-white hover:text-purple-400 font-medium"
            >
              Home
            </a>
            <a
              href="#trending"
              className="text-white hover:text-purple-400 font-medium"
            >
              Trending
            </a>
            <a
              href="#popular"
              className="text-white hover:text-purple-400 font-medium"
            >
              Popular
            </a>
            <a
              href="#top-rated"
              className="text-white hover:text-purple-400 font-medium"
            >
              Top Rated
            </a>

            {!user ? (
              <>
                <Link to="/login" className="text-white hover:text-purple-400 font-medium">Login</Link>
                <Link to="/register" className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-full font-medium transition-colors">Sign Up</Link>
              </>
            ) : (
              <div className="flex items-center space-x-4">
                <span className="text-white font-medium">Hi, {user.username}</span>
                <button onClick={logout} className="text-white hover:text-red-400 font-medium">Logout</button>
              </div>
            )}



          </nav>

          {/* Desktop Search */}
          <div
            className="hidden md:block relative search-container"
            ref={searchContainerRef}
          >
            <input
              value={searchQry}
              onChange={(e) => setSearchQry(e.target.value)}
              onFocus={handleSearchFocus}
              type="text"
              placeholder="Search Movies....."
              className="bg-neutral-800/80 text-white px-4 py-2 rounded-full text-sm
              w-48 focus:w-64 transition-all duration-300 focus:outline-none focus:ring-2
              focus:ring-purple-500/50"
            />

            {/* Conditional Rendering */}
            {isSearching ? (
              <div className="absolute right-3 top-2.5">
                <svg
                  className="w-4 h-4 text-neutral-400"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.692 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  />
                </svg>
              </div>
            ) : (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4 absolute right-3 top-3 text-neutral-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            )}

            {/* Search Result Box */}
            {showSearchResult && searchResult.length > 0 && (
              <div className="absolute mt-2 w-72 bg-neutral-800 rounded-lg shadow-lg overflow-hidden z-50">
                <ul className="divide-y divide-neutral-700">
                  {searchResult.map((movie) => {
                    return (
                      <li key={movie.id} className="hover:bg-neutral-700">
                        <button
                          className="flex items-center p-3 w-full text-left"
                          onClick={() => handleMovieSelect(movie.id)}
                        >
                          <div className="w-10 h-10 bg-neutral-700 rounded overflow-hidden flex-shrink:0">
                            {movie.poster_path ? (
                              <img
                                src={getImageURL(movie.poster_path, "w92")}
                                alt=""
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-neutral-500 text-xs">
                                No image
                              </div>
                            )}
                          </div>
                          <div className="ml-3 flex-1">
                            <p className="text-sm font-medium text-white truncate">
                              {movie.title}
                            </p>
                            <p className="text-xs text-neutral-400">
                              {movie.release_date
                                ? movie.release_date.split("-")[0]
                                : "N/A"}
                            </p>
                          </div>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </div>
            )}

            {/* No Results Box */}
            {showSearchResult &&
              searchQry.trim().length > 2 &&
              (!searchResult || searchResult.length === 0) &&
              !isSearching && (
                <div className="absolute mt-2 w-72 bg-neutral-800 rounded-lg shadow-lg overflow-hidden z-50">
                  <div className="p-4 text-center text-neutral-400 text-sm">
                    No movies found matching...
                  </div>
                </div>
              )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {/* Conditional Rendering */}
            {isMobileMenuOpen ? (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            ) : (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="mt-4 pb-4 space-y-4 md:hidden" ref={mobileMenuRef}>
            {/* Mobile Search */}
            <div className="relative mb-6">
              <input
                value={searchQry}
                onChange={(e) => setSearchQry(e.target.value)}
                onFocus={handleSearchFocus}
                type="text"
                placeholder="Search Movies....."
                className="w-full bg-neutral-800/80 text-white px-4 py-3 rounded-lg text-sm
                focus:outline-none focus:ring-2 focus:ring-purple-500/50"
              />
              {isSearching && (
                <div className="absolute right-3 top-3.5">
                  <svg className="animate-spin h-5 w-5 text-neutral-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.692 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                </div>
              )}

              {/* Mobile Search Results */}
              {showSearchResult && searchResult.length > 0 && (
                <div className="absolute mt-2 w-full bg-neutral-800 rounded-lg shadow-lg overflow-hidden z-50">
                  <ul className="divide-y divide-neutral-700">
                    {searchResult.map((movie) => (
                      <li key={movie.id} className="hover:bg-neutral-700">
                        <button
                          className="flex items-center p-3 w-full text-left"
                          onClick={() => handleMovieSelect(movie.id)}
                        >
                          <div className="w-10 h-10 bg-neutral-700 rounded overflow-hidden flex-shrink:0">
                            {movie.poster_path ? (
                              <img
                                src={getImageURL(movie.poster_path, "w92")}
                                alt=""
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-neutral-500 text-xs">
                                No image
                              </div>
                            )}
                          </div>
                          <div className="ml-3 flex-1">
                            <p className="text-sm font-medium text-white truncate">
                              {movie.title}
                            </p>
                            <p className="text-xs text-neutral-400">
                              {movie.release_date
                                ? movie.release_date.split("-")[0]
                                : "N/A"}
                            </p>
                          </div>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <a href="#" className="block text-white hover:text-purple-400 py-2" onClick={() => setIsMobileMenuOpen(false)}>
              Home
            </a>
            <a
              href="#trending"
              className="block text-white hover:text-purple-400 py-2" onClick={() => setIsMobileMenuOpen(false)}
            >
              Trending
            </a>
            <a href="#popular" className="block text-white hover:text-purple-400 py-2" onClick={() => setIsMobileMenuOpen(false)}>
              Popular
            </a>
            <a
              href="#top-rated"
              className="block text-white hover:text-purple-400 py-2" onClick={() => setIsMobileMenuOpen(false)}
            >
              Top Rated
            </a>
            {!user ? (
              <>
                <Link to="/login" className="block text-white hover:text-purple-400 py-2" onClick={() => setIsMobileMenuOpen(false)}>Login</Link>
                <Link to="/register" className="block text-white hover:text-purple-400 py-2" onClick={() => setIsMobileMenuOpen(false)}>Sign Up</Link>
              </>
            ) : (
              <>
                <div className="block text-white py-2">Hi, {user.username}</div>
                <button onClick={() => { logout(); setIsMobileMenuOpen(false); }} className="block text-white hover:text-red-400 py-2 w-full text-left">Logout</button>
              </>
            )}

          </div>
        )}
      </div>
    </header>
  );
}

export default NavBar;
